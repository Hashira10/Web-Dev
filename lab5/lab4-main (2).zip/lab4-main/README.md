# angular-web

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-hxgc22-nyyn5g)